Gibson L-5 CES get_age() - Expected 98. Got 98
Another Guitar get_age() - Expected 7. Got 7
Gibson L-5 CES is_vintage() - Expected True. Got True
Another Guitar is_vintage() - Expected False. Got False