# CP1404 Assignment 1 - Travel Tracker
Assignment 1 for CP1404/CP5632, IT@JCU

By: **Hein Htet Ko**  

This repo contains starter files including a Python file and two CSV files.  
(`temp.csv` is to copy from in case you delete the contents of `places.csv` and want the original data back).  
**Edit this README file**, replacing this paragraph with your own assignment name and details.  
At the end of the project, complete the very brief project reflection below by answering the questions (replace the `answer...` parts).  
Note: If you use the free WakaTime service on your own machine, you can track exactly how long you spent in code (over one week).  
See https://trello.com/c/6H24THnj/21-wakatime-time-tracking-for-ides-join-our-leaderboard

1. How long did the entire assignment 1 project take you?
> 3 Days

2. What do you plan to do  differently in your development process for assignment 2?
> answer...