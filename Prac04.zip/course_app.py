from prac_04.subject_reader import *

print("Travel Tracker 1.0 - by Lindsay Ward")
print("3 places loaded from places.csv")
MENU = """
V - View all courses
A - Add course
Q - Quit """


def main():
    courses = get_data()
    choice = input(MENU)

    while choice!='Q':
        if choice == 'V':
            display_courses(courses)
        elif choice == 'A':
            add_course(courses)
        elif choice =='Q':
            print("See you again")
        else:
            print("Invalid Choice!")

        choice = input(MENU)

    print("Please visit us again")


def add_course(courses):

    course_name = input("Course name:")
    if is_duplicate_course(courses, course_name):
        print("Duplicate course name")
    else:
        lecturer = input("Lecturer in charge:")
        number_of_students = int(input("Number of students:"))

        new_course = [course_name, lecturer, number_of_students]
        courses.append(new_course)

        print("New Course added")


def is_duplicate_course(courses, course_name):
    for course in courses:
        if course_name.strip() == course[0]:
            return True
        return False

if __name__ == '__main__':
    main()